const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');

menuToggle.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.textContent = isOpen ? '×' : '☰';
});

nav.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.textContent = '☰';
  });
});

document.getElementById('year').textContent = new Date().getFullYear();

const WHATSAPP_NUMBER = '918977211378';
document.getElementById('bookingForm').addEventListener('submit', event => {
  event.preventDefault();
  const form = event.currentTarget;
  const name = form.customerName.value.trim();
  const vehicle = form.vehicle.value;
  const date = form.deliveryDate.value || 'Not decided yet';
  const message = form.message.value.trim() || 'No extra details';
  const text = [
    'Hi SHOOT ELITE! I would like to enquire about a vehicle delivery photoshoot.',
    '',
    `Name: ${name}`,
    `Vehicle: ${vehicle}`,
    `Delivery date: ${date}`,
    `Details: ${message}`,
    '',
    'Please share availability and package details. Thank you!'
  ].join('\n');
  document.getElementById('formStatus').textContent = 'Opening WhatsApp with your enquiry…';
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
});
