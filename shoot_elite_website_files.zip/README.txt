SHOOT ELITE WEBSITE — FREE MOBILE-FRIENDLY STARTER
================================================

FILES
- index.html: website content
- style.css: premium black-and-gold responsive design
- script.js: mobile menu and WhatsApp booking form

BEFORE PUBLISHING
1. Check the WhatsApp number in index.html and script.js.
   Current number: +91 8977211378
2. Instagram is linked to https://www.instagram.com/shoot_elite/
3. Sample gallery photos are from Unsplash and are illustrative stock images, not confirmed customer work.
4. The website uses Google Fonts and Unsplash image URLs, so those parts need internet access to load.
5. Test the WhatsApp booking form on your phone.

PUBLISH FOR FREE WITH GITHUB PAGES (ANDROID PHONE)
1. Sign in at https://github.com/ or create a free account.
2. In GitHub, tap +, then New repository.
3. Repository name: shoot-elite
4. Set it to Public and create the repository.
5. Open the repository and use Add file > Create new file (or the + menu).
6. Create index.html, paste in the full contents of the local index.html file, then commit the file.
7. Repeat for style.css and script.js, keeping all three files in the repository root (not in a folder).
8. Open repository Settings > Pages.
9. Under Build and deployment, choose Deploy from a branch.
10. Choose branch main and folder /(root), then Save.
11. Wait a few minutes and revisit Settings > Pages for the published URL. It will usually look like:
    https://YOUR-GITHUB-USERNAME.github.io/shoot-elite/
12. Open that URL on your phone and test every link and the booking form.

IF YOUR GITHUB MOBILE UI LOOKS DIFFERENT
Open GitHub in Chrome and use the browser menu > Desktop site, or use GitHub's web interface from a computer if available. You do not need to install a code editor.

FREE HOSTING NOTES
- GitHub Pages is intended for static websites. This site uses HTML, CSS and JavaScript only.
- A custom .com domain is optional and normally costs money.
- Keep the repository public for the standard free GitHub Pages workflow.
- The form opens WhatsApp with a pre-filled message. It does not send anything automatically.
